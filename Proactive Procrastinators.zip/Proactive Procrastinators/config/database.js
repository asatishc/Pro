module.exports = {

    'url' : 'mongodb://localhost:27017/mydb' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

};